<template>
  <div>
    经济人管理
  </div>
</template>
<script>
export default {}
</script>
<style>

</style>
